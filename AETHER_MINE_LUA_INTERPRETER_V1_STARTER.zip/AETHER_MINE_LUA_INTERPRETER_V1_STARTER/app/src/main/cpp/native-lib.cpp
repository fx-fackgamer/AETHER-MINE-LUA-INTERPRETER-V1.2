#include <jni.h>
#include <string>
#include <sstream>
#include <mutex>
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

static std::mutex luaMutex;

static int capturePrint(lua_State* L) {
    std::ostringstream* output =
        static_cast<std::ostringstream*>(lua_touserdata(L, lua_upvalueindex(1)));
    int n = lua_gettop(L);
    for (int i = 1; i <= n; ++i) {
        if (i > 1) (*output) << "\t";
        size_t len = 0;
        const char* s = luaL_tolstring(L, i, &len);
        output->write(s, static_cast<std::streamsize>(len));
        lua_pop(L, 1);
    }
    (*output) << "\n";
    return 0;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_aethermine_lua_MainActivity_nativeEngineStatus(JNIEnv* env, jclass) {
    return env->NewStringUTF("Lua 5.4 native library loaded");
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_aethermine_lua_MainActivity_runLua(JNIEnv* env, jclass, jstring source) {
    const char* chars = env->GetStringUTFChars(source, nullptr);
    std::string code = chars ? chars : "";
    if (chars) env->ReleaseStringUTFChars(source, chars);

    std::lock_guard<std::mutex> lock(luaMutex);
    lua_State* L = luaL_newstate();
    if (!L) return env->NewStringUTF("ERROR: Could not create Lua state.");

    luaL_openlibs(L);
    std::ostringstream output;

    lua_pushlightuserdata(L, &output);
    lua_pushcclosure(L, capturePrint, 1);
    lua_setglobal(L, "print");

    int status = luaL_loadbuffer(L, code.c_str(), code.size(), "AETHER_MINE");
    if (status == LUA_OK) status = lua_pcall(L, 0, LUA_MULTRET, 0);

    if (status != LUA_OK) {
        const char* err = lua_tostring(L, -1);
        output << "ERROR: " << (err ? err : "Unknown Lua error") << "\n";
    }
    lua_close(L);

    std::string result = output.str();
    if (result.empty() && status == LUA_OK) result = "Program finished successfully.";
    return env->NewStringUTF(result.c_str());
}
